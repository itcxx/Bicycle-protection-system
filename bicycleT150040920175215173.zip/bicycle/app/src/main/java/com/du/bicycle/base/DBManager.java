package com.du.bicycle.base;

import android.util.Log;

import com.du.bicycle.entity.BicycleLocation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * @author: lisc
 * @date: 2020-09-18 上午 10:02
 * @desc:
 */
public class DBManager {
    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver"); //加载驱动
            conn =(Connection) DriverManager.getConnection(
                    "jdbc:mysql://rm-uf6my056k0w01f457uo.mysql.rds.aliyuncs.com:3306/pusanbicycle",
                    "pusantest1", "cxjy020615");
        } catch (SQLException ex) {//错误捕捉
            ex.printStackTrace();
            Log.d("test","SQLException==>"+ex.getMessage());
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            Log.d("test","ClassNotFoundException==>"+ex.getMessage());

        }
        return conn;//返回Connection型变量conn用于后续连接
    }

    public static int insert(final String username, final String password,final String bid) throws SQLException {//增加数据
        Connection  conn = null;
        conn = getConnection();
        //使用DriverManager获取数据库连接
        Statement stmt = conn.createStatement();
        //使用Connection来创建一个Statment对象
        String sql = "insert INTO login (ID,password,bicycle_id)VALUES('"+username+"','"+password+"','"+bid+"')";//把用户名和密码插入到数据库中
        return stmt.executeUpdate(sql);
        //执行DML语句，返回受影响的记录条数
    }

    public static String querycol(final String id) throws SQLException {//读取某一行
        //加载数据库驱动
        String result = "";
        Connection  conn = null;
        conn = getConnection();
        //使用DriverManager获取数据库连接
        Statement stmt = conn.createStatement();
        //使用Connection来创建一个Statment对象
        ResultSet rs =stmt.executeQuery(
                "select password from login where ID='"+id+"'");
        //执行查询语句并且保存结果
        rs.first();//rs行指针指向第一行
        result = rs.getString(1);//返回得到的第一列的数据
        Log.d("test","id="+id+",pwd="+result);
        rs.close();//查询关闭
        return result;
    }

    public static int updateBicycle(final String name,final String col, final int key) throws SQLException {//修改数据
        Connection  conn = null;
        conn = getConnection();
        //使用DriverManager获取数据库连接
        Statement  stmt = conn.createStatement();
        //使用Connection来创建一个Statment对象
        String sql = "UPDATE login SET "+col+"="+key+" WHERE ID='"+name+"'";//修改的sql语句
        Log.d("test","update id==>"+sql);
        return stmt.executeUpdate(sql);//返回的同时执行sql语句，返回受影响的条目数量，一般不作处理
    }


    public static List<BicycleLocation> queryLocation() throws SQLException
    {
        List<BicycleLocation> result = new ArrayList<>();
        Connection  conn = null;
        conn = getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs =stmt.executeQuery("select ID,Longitude,Latitude,public from bicycle");
        while(rs.next()){
            BicycleLocation loc = new BicycleLocation();
            loc.id = rs.getInt("ID");
            loc.Lng = rs.getDouble("Longitude");
            loc.Lat = rs.getDouble("Latitude");
            loc.bPublic = rs.getInt("public");
            if(!result.contains(loc)) {
                result.add(loc);
            }
        }
        rs.close();//查询关闭
        return result;
    }
}
