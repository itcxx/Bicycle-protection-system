package com.du.bicycle

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.du.bicycle.base.Constants
import com.du.bicycle.base.DBManager
import com.du.bicycle.utils.PreferencesUtils
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        nameEt.setText( PreferencesUtils.getString(this,Constants.PrefKey.LAST_ACCOUNT,""))
        loginBtn.setOnClickListener {
            var name = nameEt.text.toString()
            var pwd = pwdEt.text.toString()
            if(TextUtils.isEmpty(name)){
                Toast.makeText(this,"please input your account",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if(TextUtils.isEmpty(pwd)){
                Toast.makeText(this,"please input your password",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Observable.just("")
                .map {
                    DBManager.querycol(name)
                }.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe { showLoading(R.string.wait_tips) }
                .subscribe({
                    Log.d("test", "result==>$it")
                    closeLoading()
                    if(it == pwd){
                        val intent = Intent(this,MainActivity::class.java)
                        PreferencesUtils.putString(this,Constants.PrefKey.LAST_ACCOUNT,name)
                        intent.putExtra("name",name)
                        startActivity(intent)
                        finish()
                    }else{
                        Toast.makeText(this,"error account or password",Toast.LENGTH_SHORT).show()
                    }
                    closeLoading()
                },{
                    Toast.makeText(this,"error account or password",Toast.LENGTH_SHORT).show()
                    closeLoading()
                    Log.d("test","error==>"+it.message)
                })
        }

        regBtn.setOnClickListener {
//            val intent = Intent(this, EActivity::class.java)
            val intent = Intent(this,MainActivity::class.java)
//            val intent = Intent(this,RegisterActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun alertPermission()
    {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                startActivity(intent)
                return
            } else {
                //绘ui代码, 这里说明6.0系统已经有权限了
            }
        }
    }
}