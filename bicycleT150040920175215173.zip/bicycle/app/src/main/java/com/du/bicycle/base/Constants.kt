package com.du.bicycle.base

object Constants
{

    const val SERVER_URL = "http://47.103.76.30/api"
    object PrefKey
    {
        const val RECORD = "record"
        const val DEVICE = "device"
        const val LAST_ACCOUNT = "last_account"
    }
}