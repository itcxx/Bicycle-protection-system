package com.du.bicycle;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;


public class WaitingDialog extends Dialog {

    private TextView mMsgTv;
    private String mMsg;
    private boolean mCanCancel;

    public WaitingDialog(Context context, String msg) {
        super(context, R.style.waitingDialogStyle);
        this.mMsg = msg;
        this.mCanCancel = true;
    }

    public WaitingDialog(Context context, String msg, boolean canceled) {
        super(context, R.style.waitingDialogStyle);
        this.mMsg = msg;
        this.mCanCancel = canceled;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_waiting);
        mMsgTv = findViewById(R.id.msg_tv);
        mMsgTv.setText(mMsg);
        LinearLayout linearLayout = this.findViewById(R.id.main_layout);
        linearLayout.getBackground().setAlpha(210);
        setCancelable(mCanCancel);
        setCanceledOnTouchOutside(false);
    }

}
