package com.du.bicycle.base

import android.app.Service
import android.content.Context
import android.os.Vibrator
import com.du.bicycle.MyApplication

object VibratorMgr {

    private var sVibrator: Vibrator? = null

    private fun getDefault(context: Context): Vibrator? {
        if (sVibrator == null) {
            sVibrator = context.getSystemService(Service.VIBRATOR_SERVICE) as Vibrator
        }
        return sVibrator
    }

    fun vibrate(context:Context)
    {
        getDefault(context)?.vibrate(longArrayOf(800, 1000, 800, 1000, 800, 1000), 1)
    }

    fun stop(context:Context)
    {
        getDefault(context)?.cancel()
    }

}