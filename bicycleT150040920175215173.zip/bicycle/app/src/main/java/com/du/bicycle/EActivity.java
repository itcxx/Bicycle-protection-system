package com.du.bicycle;

import android.annotation.SuppressLint;
import android.app.FragmentTransaction;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.du.bicycle.R;
import com.du.bicycle.entity.HistoryRecord;
import com.du.bicycle.utils.DirectionsJSONParser;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMapOptions;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class EActivity extends BaseActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private String mMapUrl;
    private HistoryRecord mHistory;
    private String[] modes = {"transit","walking","driving"};
    private int modeIdx = 0;
    private int reqCount = 0;

    @SuppressLint("HandlerLeak")
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String s1 = (String) msg.obj;
            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;
            try {
                jObject = new JSONObject(s1);
                DirectionsJSONParser parser = new DirectionsJSONParser();
                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;
            MarkerOptions markerOptions = new MarkerOptions();
            // Traversing through all the routes
            for (int i = 0; i < routes.size(); i++) {
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();
                // Fetching i-th route
                List<HashMap<String, String>> path = routes.get(i);
                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);
                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);
                    points.add(position);
                }
                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(20);
                // Changing the color polyline according to the mode
                lineOptions.color(Color.BLUE);
            }
            // Drawing polyline in the Google Map for the i-th route
            if(lineOptions != null) {
                mMap.addPolyline(lineOptions);
            }else{
                if(reqCount<4) {
                    request();
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_path);
        GoogleMapOptions googleMapOptions = new GoogleMapOptions();
        MapFragment mapFragment = MapFragment.newInstance(googleMapOptions);
        FragmentTransaction fragmentTransaction =
                getFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.map, mapFragment);
        fragmentTransaction.commit();
        mapFragment.getMapAsync(this);
        mHistory = (HistoryRecord) getIntent().getParcelableExtra("record");
        Log.d("test","history===>"+mHistory);
    }

    private void request() {
        ++reqCount;
        OkHttpClient okHttpClient = new OkHttpClient();
        mMapUrl = DirectionsJSONParser.getDirectionsUrl(new LatLng(mHistory.fromLat,mHistory.fromLng),
                new LatLng(mHistory.toLat,mHistory.toLng),getString(R.string.google_maps_key),
                modes[modeIdx++%modes.length]);
        Request request = new Request.Builder().url(mMapUrl).get().build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("test","getDerectionsURL error--->: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String s1 = response.body().string();
                Log.d("test","getDerectionsURL : " + s1);
                Message message = new Message();
                message.obj = s1;
                mHandler.sendMessage(message);
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng loc = new LatLng(mHistory.fromLat,mHistory.fromLng);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, 12));
        request();
    }
}
