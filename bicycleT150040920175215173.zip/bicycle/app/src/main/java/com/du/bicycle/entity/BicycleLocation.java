package com.du.bicycle.entity;

import java.util.Objects;

public class BicycleLocation {
    public int id;
    public double Lat;
    public double Lng;
    public int bPublic;

    @Override
    public String toString() {
        return "Location{" +
                "id=" + id +
                ", Lat=" + Lat +
                ", Lng=" + Lng +
                ", bPublic=" + bPublic +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BicycleLocation location = (BicycleLocation) o;
        return id == location.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
