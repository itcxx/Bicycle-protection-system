package com.du.bicycle

import android.app.AlertDialog
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.Vibrator
import android.util.Log
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.du.bicycle.DeviceCheckService.Companion.bAlarming
import com.du.bicycle.base.VibratorMgr


/**
 * @author: lisc
 * @date: 2020-09-18 上午 10:32
 * @desc:
 */
abstract class BaseActivity : AppCompatActivity() {

    private var waitingDialog : WaitingDialog? = null
    private var mReceiver:BicycleAlarmReceiver? = null
    private var bRuning:Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mReceiver = BicycleAlarmReceiver()
    }

    override fun onResume() {
        super.onResume()
        bRuning = true
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.du.bicycle_alarm")
        registerReceiver(mReceiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        bRuning = false
        unregisterReceiver(mReceiver)
    }

    fun showLoading(@StringRes messageRes: Int) {
        val isShowing = waitingDialog?.isShowing ?: false
        if (waitingDialog == null) {
            waitingDialog = WaitingDialog(this, getString(messageRes))
        }

        if(!isShowing){
            waitingDialog?.setCancelable(false)
            waitingDialog?.show()
        }
    }

    fun closeLoading() {
        if (waitingDialog != null) {
            waitingDialog?.dismiss()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    fun showAlarmDialog()
    {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle("Alarm")
        dialogBuilder.setMessage("you bicycle is Alarming,Check it now.")
        dialogBuilder.setCancelable(false)
        dialogBuilder.setPositiveButton(
            "OK"
        ) { _, _ ->
            bAlarming = false
            VibratorMgr.stop(this)
        }
        val alertDialog = dialogBuilder.create()
        alertDialog.show()
    }

    inner class BicycleAlarmReceiver : BroadcastReceiver() {
        override fun onReceive(
            context: Context,
            intent: Intent
        ) {
            Log.d("test", "BicycleAlarmReceiver:check alarm")
            if(bRuning) {
                showAlarmDialog()
            }
        }
    }
}