package com.du.bicycle.base

import android.content.Context
import android.text.TextUtils
import com.du.bicycle.entity.HistoryRecord
import com.du.bicycle.utils.PreferencesUtils
import com.google.gson.Gson

import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


object RecordManager {

    fun add(context:Context,record:HistoryRecord){
        var tempList = ArrayList<HistoryRecord>()
        val str = PreferencesUtils.getString(context,Constants.PrefKey.RECORD,"");
        if(!TextUtils.isEmpty(str)) {
            val type: Type = object : TypeToken<List<HistoryRecord?>?>() {}.type
            tempList = Gson().fromJson(str, type)
        }
        tempList.add(record)

        val result = Gson().toJson(tempList)
        PreferencesUtils.putString(context,Constants.PrefKey.RECORD,result)
    }

    fun getList(context: Context):List<HistoryRecord>
    {
        val str = PreferencesUtils.getString(context,Constants.PrefKey.RECORD,"");
        if(!TextUtils.isEmpty(str)) {
            val type: Type = object : TypeToken<List<HistoryRecord?>?>() {}.type
            return Gson().fromJson(str, type)
        }
        return ArrayList<HistoryRecord>()
    }

}