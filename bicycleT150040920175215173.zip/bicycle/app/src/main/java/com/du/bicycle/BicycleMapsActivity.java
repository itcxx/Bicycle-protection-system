// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.du.bicycle;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.du.bicycle.base.DBManager;
import com.du.bicycle.base.DeviceManager;
import com.du.bicycle.base.RecordManager;
import com.du.bicycle.entity.BicycleLocation;
import com.du.bicycle.entity.HistoryRecord;
import com.du.bicycle.utils.DirectionsJSONParser;
import com.du.bicycle.utils.PermissionUtils;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowCloseListener;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * This shows how to place markers on a map.
 */
public class BicycleMapsActivity extends BaseActivity implements
        OnMarkerClickListener,
        OnInfoWindowClickListener,
        OnInfoWindowLongClickListener,
        OnInfoWindowCloseListener,
        OnMyLocationButtonClickListener,
        OnMyLocationClickListener,
        OnMapAndViewReadyListener.OnGlobalLayoutAndMapReadyListener{
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private List<BicycleLocation> mBicycleLocation = new ArrayList<>();
    private boolean bControlRequest = false;
    private String[] modes = {"transit","walking","driving"};
    private int modeIdx = 0;
    private int reqCount = 0;
    private String mMapUrl;

    @Override
    public boolean onMyLocationButtonClick() {
        Toast.makeText(this, "MyLocation button clicked", Toast.LENGTH_SHORT).show();

        return false;
    }

    @Override
    public void onMyLocationClick(@NonNull Location location) {
        Toast.makeText(this, "Current location:\n" + location, Toast.LENGTH_LONG).show();
    }

    private GoogleMap mMap;
    private Marker mLastSelectedMarker;
    private Location myLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bicycle_maps);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Location");

        findViewById(R.id.pathBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myLocation != null && mLastSelectedMarker != null && !bControlRequest){
                    request();
                    bControlRequest = true;
                }else{
                    if(myLocation == null) {
                        Toast.makeText(BicycleMapsActivity.this,
                                "please wait to get your location", Toast.LENGTH_SHORT).show();
                    }else if(mLastSelectedMarker == null){
                        Toast.makeText(BicycleMapsActivity.this,
                                "please select a bicycle marker",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        new OnMapAndViewReadyListener(mapFragment, this);

        Disposable d = Observable.just("")
            .map(new Function<String, List<BicycleLocation>>() {
                @Override
                public List<BicycleLocation> apply(String s) throws Exception {
                    return DBManager.queryLocation();
                }
            }).subscribeOn(Schedulers.io())
             .observeOn(AndroidSchedulers.mainThread())
            .subscribe(new Consumer<List<BicycleLocation>>() {
                @Override
                public void accept(List<BicycleLocation> locations) throws Exception {
                    mBicycleLocation.clear();
                    mBicycleLocation.addAll(locations);
                    for(BicycleLocation loc:mBicycleLocation){
                        Log.d("test","bicycle location:"+loc);
                    }
                    if(mBicycleLocation.size()>0) {
                        addMarkersToMap();
                    }
                }
            }, new Consumer<Throwable>() {
                @Override
                public void accept(Throwable throwable) throws Exception {
                    Toast.makeText(BicycleMapsActivity.this, "search location error",
                            Toast.LENGTH_SHORT).show();
                }
            });
    }

        /**
         * Enables the My Location layer if the fine location permission has been granted.
         */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            PermissionUtils.requestPermission(this, LOCATION_PERMISSION_REQUEST_CODE,
                    Manifest.permission.ACCESS_FINE_LOCATION, true);
        }
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;
        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMyLocationClickListener(this);
        enableMyLocation();
        // Hide the zoom controls as the button panel will cover it.
        mMap.getUiSettings().setZoomControlsEnabled(false);
        mMap.setOnMyLocationChangeListener(new GoogleMap.OnMyLocationChangeListener() {
            @Override
            public void onMyLocationChange(Location location) {
                Log.d("test","mylocation====>"+location.getLongitude()+","+location.getLatitude());
                myLocation = location;
            }
        });
        if(mBicycleLocation.size()>0) {
            addMarkersToMap();
        }
        mMap.setOnMarkerClickListener(this);
        mMap.setOnInfoWindowClickListener(this);
        mMap.setOnInfoWindowCloseListener(this);
        mMap.setOnInfoWindowLongClickListener(this);
        mMap.setContentDescription("Map with lots of markers.");
    }

    private void addMarkersToMap() {

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for(int i=0;i<mBicycleLocation.size();i++){
            BicycleLocation bicycleLocation = mBicycleLocation.get(i);
            LatLng latLng = new LatLng(bicycleLocation.Lat,bicycleLocation.Lng);
            builder.include(latLng);
        }
        LatLngBounds bounds = builder.build();
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));
        for(int i=0;i<mBicycleLocation.size();i++){
            BicycleLocation bicycleLocation = mBicycleLocation.get(i);
            LatLng latLng = new LatLng(bicycleLocation.Lat,bicycleLocation.Lng);
            mMap.addMarker(new MarkerOptions()
                .position(latLng)
                .title("bicycle_"+i)
                .snippet(String.valueOf(bicycleLocation.id)));
        }
    }

    @Override
    public boolean onMarkerClick(final Marker marker) {
        // Markers have a z-index that is settable and gettable.
        float zIndex = marker.getZIndex() + 1.0f;
        marker.setZIndex(zIndex);
        mLastSelectedMarker = marker;
        bControlRequest = false;
        reqCount = 0;
        modeIdx = 0;
        Log.d("test","last mark:"+marker.getPosition().latitude+","+marker.getPosition().longitude);
        return false;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        Toast.makeText(this, "Click Info Window", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onInfoWindowClose(Marker marker) { }

    @Override
    public void onInfoWindowLongClick(Marker marker) {
        Toast.makeText(this, "Info Window long click", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.history_item:
                startActivity(new Intent(this, HistoryPathActivity.class));
                break;
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    private void request() {
        LatLng start = new LatLng(35.230625,129.08489);
        LatLng dest = new LatLng(35.230625,129.09489);
        ++reqCount;
//        LatLng start = new LatLng(myLocation.getLatitude(),myLocation.getLongitude());
//        LatLng dest = new LatLng(mLastSelectedMarker.getPosition().latitude,mLastSelectedMarker.getPosition().longitude);
        OkHttpClient okHttpClient = new OkHttpClient();
        mMapUrl = DirectionsJSONParser.getDirectionsUrl(start, dest,getString(R.string.google_maps_key),
                modes[modeIdx++%modes.length]);
        Request request = new Request.Builder().url(mMapUrl).get().build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("test","getDerectionsURL error--->: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String s1 = response.body().string();
                Log.d("test","getDerectionsURL : " + s1);
                Message message = new Message();
                message.obj = s1;
                mHandler.sendMessage(message);
            }
        });
    }

    @SuppressLint("HandlerLeak")
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            String s1 = (String) msg.obj;
            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;
            try {
                jObject = new JSONObject(s1);
                DirectionsJSONParser parser = new DirectionsJSONParser();
                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            ArrayList<LatLng> points = null;
            PolylineOptions lineOptions = null;
            MarkerOptions markerOptions = new MarkerOptions();
            // Traversing through all the routes
            for (int i = 0; i < routes.size(); i++) {
                points = new ArrayList<LatLng>();
                lineOptions = new PolylineOptions();
                // Fetching i-th route
                List<HashMap<String, String>> path = routes.get(i);
                // Fetching all the points in i-th route
                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);
                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);
                    points.add(position);
                }
                // Adding all the points in the route to LineOptions
                lineOptions.addAll(points);
                lineOptions.width(20);
                // Changing the color polyline according to the mode
                lineOptions.color(Color.BLUE);
            }
            if(lineOptions != null) {
                mMap.addPolyline(lineOptions);
//                LatLng start = new LatLng(mLastSelectedMarker.getPosition().latitude,mLastSelectedMarker.getPosition().longitude);
                LatLng start = new LatLng(35.230625,129.08489);
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(start, 12));
                String id = mLastSelectedMarker.getSnippet();
                HistoryRecord historyRecord = new HistoryRecord();
                historyRecord.fromLat  = myLocation.getLatitude();
                historyRecord.fromLng  = myLocation.getLongitude();
                historyRecord.toLat  = mLastSelectedMarker.getPosition().latitude;
                historyRecord.toLng  = mLastSelectedMarker.getPosition().longitude;
                historyRecord.bId = mLastSelectedMarker.getTitle();
                historyRecord.timeStamp = System.currentTimeMillis();
                if(DeviceManager.INSTANCE.containId(BicycleMapsActivity.this,id)) {
                    RecordManager.INSTANCE.add(BicycleMapsActivity.this, historyRecord);
                }
            }else{
                if(reqCount<4) {
                    request();
                }
            }
        }
    };

}
