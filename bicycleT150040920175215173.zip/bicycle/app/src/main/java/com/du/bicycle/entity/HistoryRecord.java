package com.du.bicycle.entity;

import android.os.Parcel;
import android.os.Parcelable;

import com.du.bicycle.HistoryPathActivity;
import com.google.android.gms.maps.model.LatLng;

import java.io.Serializable;

public class HistoryRecord implements Parcelable {
    public String bId;
    public double fromLat;
    public double fromLng;
    public double toLat;
    public double toLng;
    public long timeStamp;

    public HistoryRecord(){}

    protected HistoryRecord(Parcel in) {
        bId = in.readString();
        fromLat = in.readDouble();
        fromLng = in.readDouble();
        toLat = in.readDouble();
        toLng = in.readDouble();
        timeStamp = in.readLong();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(bId);
        dest.writeDouble(fromLat);
        dest.writeDouble(fromLng);
        dest.writeDouble(toLat);
        dest.writeDouble(toLng);
        dest.writeLong(timeStamp);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<HistoryRecord> CREATOR = new Creator<HistoryRecord>() {
        @Override
        public HistoryRecord createFromParcel(Parcel in) {
            return new HistoryRecord(in);
        }

        @Override
        public HistoryRecord[] newArray(int size) {
            return new HistoryRecord[size];
        }
    };
}
