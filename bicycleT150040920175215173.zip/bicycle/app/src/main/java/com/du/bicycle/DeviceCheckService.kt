package com.du.bicycle

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.Vibrator
import android.text.TextUtils
import android.util.Log
import com.du.bicycle.base.Constants
import com.du.bicycle.base.VibratorMgr
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class DeviceCheckService : Service() {
    private var mDisposable: Disposable? = null
    private var host = Constants.SERVER_URL

    companion object{
        var bAlarming = false
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("test","service onCreate")
        queryDeviceState()
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        Log.d("test","service onStartCommand")
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("test","service onDestroy")
        mDisposable?.dispose()
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    private fun queryDeviceState()
    {
        if(mDisposable != null){
            return
        }
        mDisposable = Observable.interval(10, TimeUnit.SECONDS)
            .map {
                var result = ""
                val client = OkHttpClient.Builder().build()
                val url = "$host/queryDeviceProp"
                Log.d("test","url==>"+url)
                val request: Request = Request.Builder().url(url).get().build()
                val call: Call = client.newCall(request)
                try {
                    val response: Response = call.execute()
                    result = response.body()?.string() ?: ""
                } catch (e: IOException) {
                    e.printStackTrace()
                    Log.d("test","exception ==>"+e.message)
                }
                result
            }.subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                checkState(it)
            },{ Log.d("test","error==>"+it.message) })
    }

    private fun checkState(it:String)
    {
        if(TextUtils.isEmpty(it)){
            return
        }
        Log.d("test", "set device prop response=>$it")
        val result = JSONObject(it)
        val status = result.optBoolean("Success")
        if(status) {
            val jsonData = result.optJSONObject("Data")
            val jsonList = jsonData.optJSONObject("List")
            val jsonProp = jsonList.optJSONArray("PropertyStatusInfo")
            for (i in 0..jsonProp.length()) {
                val item = jsonProp.optJSONObject(i)
                val prop = item.optString("Identifier")
                if (prop == "ForcedAlarmSwitch") {
                    val v = item.optInt("Value")
                    if (v == 1) {
                        alarm()
                    } else {
                        Log.d("test","check is fine")
                    }
                    break
                }
            }
        }
    }

    private fun alarm()
    {
        if(!bAlarming) {
            bAlarming = true
            val intent = Intent()
            intent.setPackage(packageName)
            intent.action = "com.du.bicycle_alarm"
            sendBroadcast(intent)
            VibratorMgr.vibrate(this)
        }
    }
}