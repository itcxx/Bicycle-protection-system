package com.du.bicycle.base

import android.content.Context
import android.text.TextUtils
import com.du.bicycle.entity.DeviceInfo
import com.du.bicycle.utils.PreferencesUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


object DeviceManager {

    fun getList(context: Context,userId:String):List<DeviceInfo>
    {
        val str = PreferencesUtils.getString(context,Constants.PrefKey.DEVICE+"_$userId","");
        if(!TextUtils.isEmpty(str)) {
            val type: Type = object : TypeToken<List<DeviceInfo?>?>() {}.type
            return Gson().fromJson(str, type)
        }
        return ArrayList<DeviceInfo>()
    }

    fun saveList(context: Context,devices:List<DeviceInfo>,userId:String){
        val result = Gson().toJson(devices)
        PreferencesUtils.putString(context,Constants.PrefKey.DEVICE+"_$userId",result)
    }

    fun containId(context: Context,id:String):Boolean
    {
        val userId = PreferencesUtils.getString(context,Constants.PrefKey.LAST_ACCOUNT,"")
        val str = PreferencesUtils.getString(context,Constants.PrefKey.DEVICE+"_$userId","");
        if(!TextUtils.isEmpty(str)) {
            val type: Type = object : TypeToken<List<DeviceInfo?>?>() {}.type
            val lst:List<DeviceInfo> = Gson().fromJson(str, type)
            for(item in lst){
                if(item.id.toString() == id){
                    return true
                }
            }
        }
        return false
    }

}