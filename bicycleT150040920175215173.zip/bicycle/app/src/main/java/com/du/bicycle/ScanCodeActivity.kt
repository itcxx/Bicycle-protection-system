
package com.du.bicycle

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import cn.bingoogolapple.qrcode.core.QRCodeView
import com.kftpay.module.ui.extensions.UiExt
import kotlinx.android.synthetic.main.activity_scan_code.*

class ScanCodeActivity : BaseActivity(), QRCodeView.Delegate {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan_code)
        UiExt.setFullScreen(this)
        UiExt.fitNotchScreen(window)
        toolbarTitle.text  = "SCAN QRCode"
        zXingView.setDelegate(this)
        toolbarBack.setOnClickListener {
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        zXingView.startCamera() // 打开后置摄像头开始预览，但是并未开始识别
        zXingView.startSpotAndShowRect() // 显示扫描框，并开始识别
    }

    override fun onScanQRCodeSuccess(result: String) {
        Log.d("test", "scan qr code result==>$result")
        var data = Intent()
        data.putExtra("result",result);
        setResult(Activity.RESULT_OK,data);
        finish()
    }

    override fun onCameraAmbientBrightnessChanged(isDark: Boolean) {

    }

    override fun onScanQRCodeOpenCameraError() {

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        zXingView.startSpotAndShowRect()
    }


    override fun onStop() {
        super.onStop()
        zXingView.stopCamera()
    }

    override fun onDestroy() {
        super.onDestroy()
        zXingView.onDestroy()
    }

}