package com.du.bicycle

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import com.du.bicycle.base.Constants
import com.du.bicycle.entity.DeviceInfo
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_device.*
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class DeviceActivity : BaseActivity() {
    private var host = Constants.SERVER_URL
    private var mDeviceInfo: DeviceInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device)
        supportActionBar?.setHomeButtonEnabled(true);
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mDeviceInfo = intent.getParcelableExtra("device")
        title = mDeviceInfo?.name?:"bicycle"
        startService(Intent(this,DeviceCheckService::class.java))

        muteBtn.setOnClickListener {
            setDeviceProp(0)
        }

        unlockBtn.setOnClickListener {
            setDeviceProp(2)
        }

        markerBtn.setOnClickListener {
            startActivity(Intent(this, BicycleMapsActivity::class.java))
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)
    }


    private fun setDeviceProp(value:Int)
    {
        var d = Observable.just(value)
            .map {
                var result = ""
                val client = OkHttpClient.Builder().build()
                val url = "$host/setDeviceprop?val=$value&id=2"
                Log.d("test","url==>"+url)
                val request: Request = Request.Builder().url(url).get().build()
                val call: Call = client.newCall(request)
                try {
                    val response: Response = call.execute()
                    result = response.body()?.string() ?: ""
                } catch (e: IOException) {
                    e.printStackTrace()
                    Log.d("test","exception ==>"+e.message)
                }
                result
            }.subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { showLoading(R.string.wait_tips) }
            .subscribe({
                Log.d("test", "set device prop response=>$it")
                closeLoading()
            },{
                Log.d("test","error==>"+it.message)
                closeLoading()
            })
    }


}