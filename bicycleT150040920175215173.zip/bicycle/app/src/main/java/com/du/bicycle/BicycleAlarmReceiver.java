//package com.du.bicycle;
//
//import android.app.AlertDialog;
//import android.app.Service;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.Intent;
//import android.os.Vibrator;
//import android.util.Log;
//import android.view.WindowManager;
//
//public class BicycleAlarmReceiver extends BroadcastReceiver {
//    @Override
//    public void onReceive(final Context context, Intent intent) {
//        Log.d("test","BicycleAlarmReceiver:check alarm");
//        AlertDialog.Builder dialogBuilder =  new AlertDialog.Builder(context);
//        dialogBuilder.setTitle("Alarm");
//        dialogBuilder.setMessage("you bicycle is Alarming,Check it now.");
//        dialogBuilder.setCancelable(false);
//        dialogBuilder.setPositiveButton("OK",
//            new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialog, int which) {
//                    DeviceCheckService.Companion.setBAlarming(false);
//                    Vibrator vib = (Vibrator) context.getSystemService(Service.VIBRATOR_SERVICE);
//                    vib.cancel();
//                }
//            });
//        AlertDialog alertDialog = dialogBuilder.create();
//        alertDialog.show();
//    }
//}