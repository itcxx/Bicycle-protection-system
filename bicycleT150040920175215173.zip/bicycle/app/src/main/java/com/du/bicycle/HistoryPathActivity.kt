package com.du.bicycle

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.du.bicycle.base.CommonAdapter
import com.du.bicycle.base.CommonViewHolder
import com.du.bicycle.base.RecordManager
import com.du.bicycle.entity.HistoryRecord
import kotlinx.android.synthetic.main.activity_history_path.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class HistoryPathActivity : BaseActivity() {

    private var mAdapter:CommonAdapter<HistoryRecord>? = null
    private var mDatas = ArrayList<HistoryRecord>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_path)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        initData()
        mAdapter = object:CommonAdapter<HistoryRecord>(R.layout.item_history,mDatas){
            override fun convert(holder: CommonViewHolder, item: HistoryRecord, position: Int) {
                holder.setTvText(R.id.titleTv,item.bId)
                holder.setTvText(R.id.infoTv,String.format("from(%f,%f) \t to(%f,%f) ",
                    item.fromLat,item.fromLng,
                    item.toLat,item.toLng))
                holder.setTvText(R.id.timeTv,"time:"+fmtDate(item.timeStamp))
            }
        }
        historyLv.adapter = mAdapter

        historyLv.setOnItemClickListener { _, _, position, _ ->
            var historyRecord = mDatas.get(position);
            var intent = Intent(this@HistoryPathActivity,
                EActivity::class.java)
            intent.putExtra("record",historyRecord)
            startActivity(intent)
        }
    }

    private fun initData()
    {
        mDatas.addAll(RecordManager.getList(this))
    }
    fun fmtDate(timeStamp:Long):String
    {
        val date = Date()
        date.time = timeStamp
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        return format.format(date);
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
        }
        return super.onOptionsItemSelected(item)
    }

}