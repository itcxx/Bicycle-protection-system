package com.du.bicycle

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Service
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Vibrator
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.du.bicycle.base.CommonAdapter
import com.du.bicycle.base.CommonViewHolder
import com.du.bicycle.base.DBManager
import com.du.bicycle.base.DeviceManager
import com.du.bicycle.entity.DeviceInfo
import com.tbruyelle.rxpermissions2.RxPermissions
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit


class MainActivity : BaseActivity() {
    private var mAdapter:CommonAdapter<DeviceInfo>? = null
    private var mUserId:String = ""
    private var mData:ArrayList<DeviceInfo> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mUserId = intent.getStringExtra("name")
        Log.d("test", "main user name==>$mUserId")

        initData()
        mAdapter = object :CommonAdapter<DeviceInfo>(R.layout.item_device,mData){
            override fun convert(holder: CommonViewHolder, item: DeviceInfo, position: Int) {
                holder.setTvText(R.id.devInfo,item.name)
            }
        }
        deviceLv.adapter = mAdapter

        deviceLv.setOnItemClickListener { _, _, position, _ ->
            val device = mData[position]
            val intent = Intent(this,DeviceActivity::class.java)
            intent.putExtra("device",device)
            startActivity(intent)
        }

        deviceLv.setOnItemLongClickListener { _, _, position, _ ->
            val device = mData[position]
            val builder = AlertDialog.Builder(this)
            builder.setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            builder.setPositiveButton("Delete"){ _,_ ->
                mData.removeAt(position)
                mAdapter?.refreshView(mData)
                Toast.makeText(this,"delete device success",Toast.LENGTH_SHORT).show()
            }
            builder.setMessage("Will you Confirm to Delete this Device?")
            builder.setTitle("Tips")
            builder.show()
            true
        }
    }

    private fun initData()
    {
        mData.addAll(DeviceManager.getList(this,mUserId))
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_home, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == Activity.RESULT_OK){
            val result = data?.getStringExtra("result") ?: ""
            Log.d("test", "qr code ==>$result")
            try{
                val id = Integer.parseInt(result)
                updateBicycle(mUserId,id)
            }catch (e:NumberFormatException){
                Toast.makeText(this,"invalid QR Code,please try again", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.scan_item) {
            val rxPermissions = RxPermissions(this)
            val d = rxPermissions.request(Manifest.permission.CAMERA).subscribe {
                if(it){
                    startActivityForResult(Intent(this,ScanCodeActivity::class.java),100)
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopService(Intent(this,DeviceCheckService::class.java))
        DeviceManager.saveList(this,mData,mUserId)
    }

    private fun updateBicycle(name:String?, id:Int)
    {
        var d = Observable.just(id)
            .map {
                DBManager.updateBicycle(name,"bicycle_id",id)
            }.subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { showLoading(R.string.wait_tips) }
            .subscribe({
                Log.d("test", "result==>$it")
                closeLoading()
                if(it >= 1){
                    val dev = DeviceInfo(id, "bicycle_$id")
                    mData.add(dev)
                    mAdapter?.refreshView(mData)
                    Toast.makeText(this,"add bicycle success", Toast.LENGTH_SHORT).show()
                }else{
                    Toast.makeText(this," add bicycle failed", Toast.LENGTH_SHORT).show()
                }
                closeLoading()
            },{
//                Toast.makeText(this,"update bicycle information failed", Toast.LENGTH_SHORT).show()
                closeLoading()
                Log.d("test","error==>"+it.message)
            })
    }
}